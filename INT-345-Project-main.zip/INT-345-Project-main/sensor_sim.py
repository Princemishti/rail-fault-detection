import requests
import os
import time
import random

def simulate_sensor():
    with open("dataset_path.txt", "r") as f:
        dataset_path = f.read().strip()
    
    test_root = os.path.join(dataset_path, "Railway Track fault Detection Updated", "Test")
    classes = ["Defective", "Non defective"]
    
    # Collect all test images
    test_images = []
    for cls in classes:
        cls_path = os.path.join(test_root, cls)
        if os.path.exists(cls_path):
            images = [os.path.join(cls_path, img) for img in os.listdir(cls_path) if img.lower().endswith(('.jpg', '.jpeg', '.png'))]
            test_images.extend(images)
    
    if not test_images:
        print("No test images found to simulate!")
        return

    print(f"Starting IoT Sensor Simulation with {len(test_images)} images...")
    url = "http://localhost:8000/predict"
    
    battery = 100
    
    while True:
        # Simulate battery drain
        battery -= random.uniform(0.1, 0.5)
        if battery < 10:
            print("Low battery! Simulation stopping for 'recharge'...")
            time.sleep(10)
            battery = 100
            continue
            
        img_path = random.choice(test_images)
        print(f"Sensor sending image: {os.path.basename(img_path)} (Battery: {battery:.1f}%)")
        
        try:
            with open(img_path, "rb") as img_file:
                files = {"file": (os.path.basename(img_path), img_file, "image/jpeg")}
                response = requests.post(url, files=files)
                
            if response.status_code == 200:
                result = response.json()
                print(f"  Response: {result['status']} ({result['confidence']}%)")
            else:
                print(f"  Error: {response.status_code}")
        except Exception as e:
            print(f"  Server unreachable: {e}")
            
        # Wait for 5 seconds before next "transmission"
        time.sleep(5)

if __name__ == "__main__":
    simulate_sensor()
