from fastapi import FastAPI, File, UploadFile, Request
from fastapi.responses import HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from ultralytics import YOLO
import shutil
import os
import time
from datetime import datetime
from PIL import Image
import io

app = FastAPI()

# Load the trained model
model = YOLO("model.pt")

# Configure templates and static files
templates = Jinja2Templates(directory="templates")
app.mount("/static", StaticFiles(directory="static"), name="static")

# Ensure a directory for uploaded images exists
UPLOAD_DIR = "static/uploads"
os.makedirs(UPLOAD_DIR, exist_ok=True)

# In-memory history of detections
detection_history = []

import asyncio
import random
from fastapi import BackgroundTasks

# Simulation state
simulation_running = False
battery_level = 85.0
current_img_idx = 0

async def run_simulation():
    global simulation_running, battery_level, current_img_idx
    
    # Check for sample_images first (for deployment), then fallback to Kaggle dataset
    test_images = []
    if os.path.exists("sample_images"):
        for root, dirs, files in os.walk("sample_images"):
            for file in files:
                if file.lower().endswith(('.jpg', '.jpeg', '.png')):
                    test_images.append(os.path.join(root, file))
    
    if not test_images and os.path.exists("dataset_path.txt"):
        with open("dataset_path.txt", "r") as f:
            dataset_path = f.read().strip()
        
        test_root = os.path.join(dataset_path, "Railway Track fault Detection Updated", "Test")
        classes = ["Defective", "Non defective"]
        for cls in classes:
            cls_path = os.path.join(test_root, cls)
            if os.path.exists(cls_path):
                images = [os.path.join(cls_path, img) for img in os.listdir(cls_path) if img.lower().endswith(('.jpg', '.jpeg', '.png'))]
                test_images.extend(images)
    
    random.shuffle(test_images)
    
    if not test_images:
        return

    while simulation_running:
        # Cycle through images
        img_path = test_images[current_img_idx % len(test_images)]
        current_img_idx += 1
        
        # Simulate battery drain
        battery_level -= random.uniform(0.1, 0.3)
        filename = os.path.basename(img_path)
        
        # Save to uploads
        timestamp = int(time.time())
        new_filename = f"{timestamp}_{filename}"
        dest_path = os.path.join(UPLOAD_DIR, new_filename)
        shutil.copy(img_path, dest_path)
        
        # Inference
        results = model(dest_path)
        result = results[0]
        probs = result.probs
        top1_idx = probs.top1
        top1_label = result.names[top1_idx]
        top1_conf = float(probs.top1conf)
        
        detection_data = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            "image_url": f"/static/uploads/{new_filename}",
            "label": top1_label,
            "confidence": round(top1_conf * 100, 2),
            "status": "FAULT" if top1_label.lower() == "defective" else "HEALTHY",
            "battery": round(battery_level, 1)
        }
        
        detection_history.insert(0, detection_data)
        if len(detection_history) > 20: detection_history.pop()
        
        await asyncio.sleep(5)

@app.get("/", response_class=HTMLResponse)
async def read_root(request: Request):
    return templates.TemplateResponse(
        request=request, name="index.html", context={
            "history": detection_history, 
            "sim_running": simulation_running,
            "battery": round(battery_level, 1)
        }
    )

@app.post("/simulation/start")
async def start_sim(background_tasks: BackgroundTasks):
    global simulation_running
    if not simulation_running:
        simulation_running = True
        background_tasks.add_task(run_simulation)
    return {"status": "started"}

@app.post("/simulation/stop")
async def stop_sim():
    global simulation_running
    simulation_running = False
    return {"status": "stopped"}

@app.get("/status")
async def get_status():
    return {
        "simulation_running": simulation_running,
        "battery": round(battery_level, 1),
        "last_detection": detection_history[0] if detection_history else None
    }

@app.post("/predict")
async def predict(file: UploadFile = File(...)):
    # Save the uploaded file
    timestamp = int(time.time())
    file_path = os.path.join(UPLOAD_DIR, f"{timestamp}_{file.filename}")
    with open(file_path, "wb") as buffer:
        shutil.copyfileobj(file.file, buffer)
    
    # Run inference
    results = model(file_path)
    
    # Process results
    # Since it's a classification model, we get the top classes
    result = results[0]
    probs = result.probs
    top1_idx = probs.top1
    top1_label = result.names[top1_idx]
    top1_conf = float(probs.top1conf)
    
    # Format detection data
    detection_data = {
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "image_url": f"/static/uploads/{timestamp}_{file.filename}",
        "label": top1_label,
        "confidence": round(top1_conf * 100, 2),
        "status": "FAULT" if top1_label.lower() == "defective" else "HEALTHY"
    }
    
    # Add to history (keep last 20)
    detection_history.insert(0, detection_data)
    if len(detection_history) > 20:
        detection_history.pop()
        
    return detection_data

@app.get("/history")
async def get_history():
    return detection_history

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
