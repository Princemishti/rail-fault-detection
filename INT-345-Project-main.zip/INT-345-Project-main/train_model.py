from ultralytics import YOLO
import os

def train_model():
    with open("dataset_path.txt", "r") as f:
        dataset_path = f.read().strip()
    
    data_dir = os.path.join(dataset_path, "Railway Track fault Detection Updated")
    
    # Load a pretrained YOLOv8n-cls model
    model = YOLO('yolov8n-cls.pt')
    
    # Train the model
    # We specify the data directory, epochs, and image size
    results = model.train(
        data=data_dir, 
        epochs=20, 
        imgsz=224, 
        batch=16,
        name='rail_track_fault_cls'
    )
    
    print("Training complete. Results saved in 'runs/classify/rail_track_fault_cls'")
    
    # Export the model
    path = model.export(format='onnx')
    print(f"Model exported to {path}")

if __name__ == "__main__":
    train_model()
